const express=require('express');
const fs=require('fs');
const app=express();

app.get("/",(req,res)=>{
	res.write("<h1>Hello suraj kumar sharma</h1>");
  res.send();
})
app.get("/about",(req,res)=>{
  res.send("HELLO ABOUT EXPRESS");
})
app.get("/userapi",(req,res)=>{
  fs.readFile("user.json","utf8",(err,data)=>{
    // console.log(data);

    res.send(data);
    //  const obj=JSON.parse(data);
    // res.send(obj[0].name)
  });
})
app.get("/contact",(req,res)=>{
  res.send("HELLO CONTACT EXPRESS");
})
app.listen(5000,()=>{
	console.log("server running");
})