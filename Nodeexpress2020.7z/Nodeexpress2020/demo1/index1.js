const http=require("http");
const server=http.createServer((req,res)=>{
  // res.end("<h1>Hello from server</h1>");
  if(req.url=="/"){
  	res.end("<h1>Hello from server</h1>");
  }else if(req.url=="/about"){
  	res.end("<h1>Hello from about server</h1>");
  }else if(req.url=="/contact"){
  	res.end("<h1>Hello from  contact server</h1>");
  }
});
server.listen(8000,()=>{
	console.log("server started......");
})