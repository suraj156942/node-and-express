const add=(a,b)=>{
	return a+b;
};
const sub=(a,b)=>{
	return a-b;
};
const mult=(a,b)=>{
	return a*b;
};
module.exports={add,sub,mult};