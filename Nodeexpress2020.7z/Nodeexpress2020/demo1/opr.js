const {add,sub,mult}=require("./index.js")
console.log(add(5,5));
console.log(sub(5,5));
console.log(mult(5,5));