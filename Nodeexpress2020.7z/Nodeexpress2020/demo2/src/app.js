const express=require('express');
const path=require('path');
const app=express();
 const StaticPath=path.join(__dirname,"../public");
  app.use(express.static(StaticPath));
app.get("/",(req,res)=>{
	res.write("<h1>Hello suraj kumar sharma</h1>");
  res.send();
})
app.get("/about",(req,res)=>{
  res.send("HELLO ABOUT EXPRESS");
})

app.listen(5000,()=>{
	console.log("server running");
})